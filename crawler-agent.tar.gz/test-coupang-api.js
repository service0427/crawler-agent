const axios = require('axios');
const https = require('https');

// HTTPS 자체 서명 인증서 허용
const httpsAgent = new https.Agent({
  rejectUnauthorized: false
});

// 허브 설정
const HUB_URL = 'https://mkt.techb.kr:8443';
const API_KEY = 'your-client-api-key'; // 실제 클라이언트 API 키로 변경

async function searchCoupang(keyword, limit = null) {
  try {
    console.log(`\n=== 쿠팡 검색 시작: ${keyword} ===`);
    
    const requestData = {
      workflow: 'coupang-search',
      params: {
        keyword: keyword
      },
      targetAgent: null // null이면 자동으로 사용 가능한 에이전트 선택
    };
    
    if (limit) {
      requestData.params.limit = limit;
    }
    
    console.log('요청 데이터:', JSON.stringify(requestData, null, 2));
    
    const response = await axios.post(
      `${HUB_URL}/api/workflow/execute`,
      requestData,
      {
        headers: {
          'Content-Type': 'application/json',
          'X-API-Key': API_KEY
        },
        httpsAgent
      }
    );
    
    console.log('\n응답 상태:', response.status);
    console.log('응답 데이터:', JSON.stringify(response.data, null, 2));
    
    // 작업 ID가 반환된 경우
    if (response.data.taskId) {
      console.log(`\n작업 ID: ${response.data.taskId}`);
      console.log('작업이 백그라운드에서 실행 중입니다.');
      
      // 작업 상태 확인 (선택사항)
      setTimeout(() => checkTaskStatus(response.data.taskId), 5000);
    }
    
    return response.data;
  } catch (error) {
    console.error('\n오류 발생:', error.message);
    if (error.response) {
      console.error('응답 상태:', error.response.status);
      console.error('응답 데이터:', error.response.data);
    }
  }
}

async function checkTaskStatus(taskId) {
  try {
    const response = await axios.get(
      `${HUB_URL}/api/workflow/status/${taskId}`,
      {
        headers: {
          'X-API-Key': API_KEY
        },
        httpsAgent
      }
    );
    
    console.log(`\n작업 ${taskId} 상태:`, response.data);
  } catch (error) {
    console.error('상태 확인 오류:', error.message);
  }
}

// 사용 가능한 에이전트 확인
async function checkAgents() {
  try {
    const response = await axios.get(
      `${HUB_URL}/api/agents`,
      {
        headers: {
          'X-API-Key': API_KEY
        },
        httpsAgent
      }
    );
    
    console.log('\n=== 사용 가능한 에이전트 ===');
    console.log(JSON.stringify(response.data, null, 2));
  } catch (error) {
    console.error('에이전트 확인 오류:', error.message);
  }
}

// 테스트 실행
async function runTest() {
  // 먼저 에이전트 상태 확인
  await checkAgents();
  
  // 쿠팡 검색 실행
  await searchCoupang('노트북', 50);
  
  // 다른 검색 예시
  // await searchCoupang('아이폰', 100);
  // await searchCoupang('에어팟', null); // 제한 없이 모든 결과
}

// 명령줄 인수 처리
if (process.argv.length > 2) {
  const keyword = process.argv[2];
  const limit = process.argv[3] ? parseInt(process.argv[3]) : null;
  searchCoupang(keyword, limit);
} else {
  runTest();
}