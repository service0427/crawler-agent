#!/bin/bash

echo "Testing coupang-search workflow with curl..."
echo ""

curl -X POST http://localhost:3001/workflow/run \
  -H "Content-Type: application/json" \
  -d '{
    "module": "coupang-search",
    "params": {
      "keyword": "노트북",
      "limit": 10
    }
  }' \
  -v