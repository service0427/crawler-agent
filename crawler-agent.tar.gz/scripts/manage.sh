#!/bin/bash

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 기본 설정
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_ROOT"

# 환경 변수 로드
if [ -f .env ]; then
    export $(cat .env | sed 's/#.*//g' | xargs)
fi

# 함수들
show_header() {
    clear
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}              Web Crawler Agent Management Tool${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo
}

check_agent_status() {
    local port=$1
    if netstat -tlnp 2>/dev/null | grep -q ":${port}.*LISTEN.*node"; then
        local pid=$(netstat -tlnp 2>/dev/null | grep ":${port}.*LISTEN.*node" | awk '{print $7}' | cut -d'/' -f1)
        echo -e "${GREEN}Running${NC} (PID: $pid)"
        return 0
    else
        echo -e "${RED}Stopped${NC}"
        return 1
    fi
}

show_status() {
    show_header
    echo -e "${YELLOW}Agent Status:${NC}"
    echo "────────────────────────────────────────"
    
    for port in 3001 3002 3003 3004; do
        echo -n "Agent on port $port: "
        check_agent_status $port
    done
    
    echo
    echo -e "${YELLOW}System Resources:${NC}"
    echo "────────────────────────────────────────"
    
    # Memory usage
    local mem_usage=$(ps aux | grep "node.*index.js" | grep -v grep | awk '{sum += $6} END {print sum/1024}')
    echo "Total Memory Usage: ${mem_usage:-0} MB"
    
    # Chrome processes
    local chrome_count=$(pgrep -f "chrome|chromium" | wc -l)
    echo "Chrome Processes: $chrome_count"
    
    # Log sizes
    local log_size=$(du -sh logs 2>/dev/null | cut -f1)
    echo "Log Directory Size: ${log_size:-0}"
}

start_single_agent() {
    echo -e "${YELLOW}Starting single agent...${NC}"
    DISPLAY=${DISPLAY:-:0} nohup node src/index.js > logs/agent.log 2>&1 &
    sleep 2
    
    if check_agent_status 3001 > /dev/null; then
        echo -e "${GREEN}✓ Agent started successfully${NC}"
    else
        echo -e "${RED}✗ Failed to start agent${NC}"
        echo "Check logs/agent.log for details"
    fi
}

start_multi_agents() {
    echo -e "${YELLOW}Starting multiple agents...${NC}"
    
    for i in {1..4}; do
        local port=$((3000 + i))
        echo -n "Starting Agent $i on port $port... "
        
        PORT=$port AGENT_ID=$i DISPLAY=${DISPLAY:-:0} nohup node src/index.js > logs/agent$i.log 2>&1 &
        sleep 1
        
        if check_agent_status $port > /dev/null; then
            echo -e "${GREEN}✓${NC}"
        else
            echo -e "${RED}✗${NC}"
        fi
    done
}

stop_all_agents() {
    echo -e "${YELLOW}Stopping all agents...${NC}"
    
    # Kill by process name
    pkill -f "node.*src/index.js" 2>/dev/null
    
    # Kill by port if still running
    for port in 3001 3002 3003 3004; do
        local pid=$(netstat -tlnp 2>/dev/null | grep ":${port}.*LISTEN.*node" | awk '{print $7}' | cut -d'/' -f1)
        if [ ! -z "$pid" ]; then
            kill -9 $pid 2>/dev/null
        fi
    done
    
    sleep 1
    echo -e "${GREEN}✓ All agents stopped${NC}"
}

view_logs() {
    echo -e "${YELLOW}Select log to view:${NC}"
    echo "1) All logs (follow)"
    echo "2) Agent 1 log"
    echo "3) Agent 2 log"
    echo "4) Agent 3 log"
    echo "5) Agent 4 log"
    echo "6) Clear all logs"
    echo "0) Back to main menu"
    
    read -p "Enter choice: " log_choice
    
    case $log_choice in
        1) tail -f logs/*.log ;;
        2) tail -f logs/agent1.log ;;
        3) tail -f logs/agent2.log ;;
        4) tail -f logs/agent3.log ;;
        5) tail -f logs/agent4.log ;;
        6) 
            read -p "Are you sure you want to clear all logs? (y/N): " confirm
            if [ "$confirm" = "y" ]; then
                rm -f logs/*.log
                echo -e "${GREEN}✓ Logs cleared${NC}"
            fi
            ;;
        0) return ;;
        *) echo -e "${RED}Invalid choice${NC}" ;;
    esac
}

configure_agent() {
    echo -e "${YELLOW}Configuration:${NC}"
    echo "────────────────────────────────────────"
    
    if [ -f .env ]; then
        echo -e "${GREEN}Current configuration (.env):${NC}"
        cat .env | grep -E "^[^#]" | sed 's/=.*$/=***/'
        echo
        echo "Edit .env file to change configuration"
    else
        echo -e "${RED}No .env file found!${NC}"
        echo "Copy .env.example to .env and configure it"
    fi
}

show_menu() {
    echo
    echo -e "${YELLOW}Main Menu:${NC}"
    echo "────────────────────────────────────────"
    echo "1) Show status"
    echo "2) Start single agent"
    echo "3) Start multiple agents (4)"
    echo "4) Stop all agents"
    echo "5) Restart all agents"
    echo "6) View logs"
    echo "7) Configuration"
    echo "8) Install/Update dependencies"
    echo "0) Exit"
    echo
    read -p "Enter your choice: " choice
}

install_update() {
    echo -e "${YELLOW}Installing/Updating dependencies...${NC}"
    npm install
    npx playwright install chromium
    echo -e "${GREEN}✓ Dependencies updated${NC}"
}

# Main loop
main() {
    while true; do
        show_header
        show_status
        show_menu
        
        case $choice in
            1) ;; # Status already shown
            2) start_single_agent ;;
            3) start_multi_agents ;;
            4) stop_all_agents ;;
            5) 
                stop_all_agents
                sleep 2
                start_multi_agents
                ;;
            6) view_logs ;;
            7) configure_agent ;;
            8) install_update ;;
            0) 
                echo "Goodbye!"
                exit 0
                ;;
            *)
                echo -e "${RED}Invalid choice${NC}"
                ;;
        esac
        
        if [ "$choice" != "0" ]; then
            echo
            read -p "Press Enter to continue..."
        fi
    done
}

# Run main function
main