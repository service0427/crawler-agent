#!/bin/bash

# 색상 정의
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 허브 설정
HUB_URL="https://mkt.techb.kr:8443"
API_KEY="your-client-api-key"  # 실제 클라이언트 API 키로 변경

echo -e "${YELLOW}=== 쿠팡 검색 크롤링 테스트 ===${NC}"
echo

# 검색 키워드 입력
read -p "검색할 키워드를 입력하세요: " KEYWORD
read -p "수집할 상품 수 (Enter로 스킵): " LIMIT

# JSON 데이터 구성
if [ -z "$LIMIT" ]; then
    JSON_DATA="{
        \"workflow\": \"coupang-search\",
        \"params\": {
            \"keyword\": \"$KEYWORD\"
        },
        \"targetAgent\": null
    }"
else
    JSON_DATA="{
        \"workflow\": \"coupang-search\",
        \"params\": {
            \"keyword\": \"$KEYWORD\",
            \"limit\": $LIMIT
        },
        \"targetAgent\": null
    }"
fi

echo -e "${YELLOW}요청 전송 중...${NC}"
echo

# API 요청
RESPONSE=$(curl -s -k -X POST "$HUB_URL/api/workflow/execute" \
    -H "Content-Type: application/json" \
    -H "X-API-Key: $API_KEY" \
    -d "$JSON_DATA")

# 결과 출력
if [ $? -eq 0 ]; then
    echo -e "${GREEN}요청 성공!${NC}"
    echo "응답:"
    echo "$RESPONSE" | jq '.' 2>/dev/null || echo "$RESPONSE"
else
    echo -e "${RED}요청 실패!${NC}"
    echo "$RESPONSE"
fi