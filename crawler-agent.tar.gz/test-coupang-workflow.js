const axios = require('axios');

async function testCoupangWorkflow() {
    const workflowRequest = {
        module: 'coupang-search',
        params: {
            keyword: '노트북',
            limit: 10
        }
    };

    console.log('Testing coupang-search workflow...');
    console.log('Request:', JSON.stringify(workflowRequest, null, 2));

    try {
        const response = await axios.post('http://localhost:3001/workflow/run', workflowRequest, {
            headers: {
                'Content-Type': 'application/json'
            },
            timeout: 60000 // 60 seconds timeout
        });

        console.log('\nResponse received!');
        console.log('Status:', response.status);
        console.log('Data:', JSON.stringify(response.data, null, 2));
    } catch (error) {
        console.error('Error occurred:');
        if (error.response) {
            console.error('Status:', error.response.status);
            console.error('Data:', error.response.data);
        } else if (error.request) {
            console.error('No response received');
        } else {
            console.error('Error:', error.message);
        }
    }
}

testCoupangWorkflow();