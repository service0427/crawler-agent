# Web Crawler Agent

분산 웹 크롤러 시스템의 에이전트 구성요소입니다. Playwright를 사용하여 Chrome 브라우저를 자동화하고, 중앙 허브와 통신하여 크롤링 작업을 수행합니다.

## 주요 기능

- **브라우저 자동화**: Playwright 기반 Chrome 브라우저 제어
- **워크플로우 시스템**: 유연한 크롤링 작업 정의 및 실행
- **허브 통신**: HTTPS를 통한 안전한 허브-에이전트 통신
- **멀티 에이전트**: 단일 서버에서 여러 에이전트 인스턴스 실행
- **크로스 플랫폼**: Windows, Linux, macOS 지원

## 시스템 요구사항

- Node.js v18 이상
- Chrome 또는 Chromium 브라우저
- 최소 2GB RAM (에이전트당)
- 최소 1GB 디스크 공간

## 빠른 시작

### Linux/macOS

```bash
# 저장소 클론
git clone https://github.com/yourusername/crawler-agent.git
cd crawler-agent

# 설치 스크립트 실행
./scripts/install.sh

# 환경 설정
cp .env.example .env
nano .env  # 허브 정보 입력

# 단일 에이전트 실행
npm start

# 또는 관리 도구 사용
./scripts/manage.sh
```

### Windows

```powershell
# 저장소 클론
git clone https://github.com/yourusername/crawler-agent.git
cd crawler-agent

# PowerShell 관리자 권한으로 실행
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
.\scripts\install.ps1

# 환경 설정
copy .env.example .env
notepad .env  # 허브 정보 입력

# 단일 에이전트 실행
npm start

# 또는 배치 파일 사용
start-agent.bat
```

## 환경 설정

`.env` 파일에서 다음 항목을 설정합니다:

```env
# 에이전트 설정
PORT=3001                    # 에이전트 포트
AGENT_ID=agent-1            # 고유 에이전트 ID

# 허브 연결
HUB_URL=https://hub.example.com:8443  # 허브 URL
HUB_SECRET=your-secret-key            # 인증 키

# 브라우저 설정
HEADLESS=false              # 헤드리스 모드 (true/false)
```

## 멀티 에이전트 실행

### Linux/macOS

```bash
# 4개 에이전트 동시 실행 (포트 3001-3004)
./scripts/start-multi-agents.sh

# 관리 도구로 제어
./scripts/manage.sh
```

### Windows

```powershell
# PowerShell에서 실행
.\scripts\start-multi-agents.ps1

# 또는 배치 파일 사용
start-multi-agents.bat
```

## 시스템 서비스로 실행

### Linux (systemd)

```bash
# 서비스 설치
sudo ./scripts/systemd-setup.sh install-multi

# 자동 시작 활성화
sudo systemctl enable crawler-agent@3001
sudo systemctl enable crawler-agent@3002
sudo systemctl enable crawler-agent@3003
sudo systemctl enable crawler-agent@3004

# 서비스 시작
sudo systemctl start crawler-agent@3001
```

### Windows (PM2)

```powershell
# PM2 설치
npm install -g pm2

# 에이전트 시작
pm2 start src/index.js --name crawler-agent

# 시스템 시작 시 자동 실행
pm2 save
pm2 startup
```

## 워크플로우 개발

워크플로우는 `src/workflows` 디렉토리에 위치합니다.

### 기본 워크플로우 구조

```javascript
module.exports = {
  name: 'example-workflow',
  version: '1.0.0',
  
  async execute(params, context) {
    const { page, logger } = context;
    
    // 페이지 이동
    await page.goto(params.url);
    
    // 데이터 추출
    const data = await page.evaluate(() => {
      return document.title;
    });
    
    return { success: true, data };
  }
};
```

## 모니터링

### 로그 확인

```bash
# 실시간 로그 보기
tail -f logs/agent.log

# 특정 에이전트 로그
tail -f logs/agent1.log
```

### 상태 확인

```bash
# 관리 도구 사용
./scripts/manage.sh

# systemd 상태
sudo systemctl status crawler-agent@3001
```

## 문제 해결

### 포트 충돌

```bash
# 사용 중인 포트 확인
netstat -tlnp | grep 3001

# 프로세스 종료
kill -9 <PID>
```

### Chrome 실행 오류

```bash
# Linux에서 의존성 설치
sudo apt-get install chromium-browser
npx playwright install-deps chromium
```

### 허브 연결 실패

1. `.env` 파일의 `HUB_URL`과 `HUB_SECRET` 확인
2. 네트워크 연결 상태 확인
3. 허브 서버 상태 확인

## 디렉토리 구조

```
crawler-agent/
├── src/                    # 소스 코드
│   ├── index.js           # 메인 에이전트 서버
│   └── workflows/         # 워크플로우 모듈
├── scripts/               # 관리 스크립트
│   ├── install.sh         # Linux 설치
│   ├── install.ps1        # Windows 설치
│   └── manage.sh          # 통합 관리 도구
├── config/                # 설정 파일
│   ├── default.json       # 기본 설정
│   └── *.service          # systemd 서비스
├── logs/                  # 로그 파일
├── data/                  # 데이터 저장
│   └── users/            # 브라우저 사용자 데이터
└── .env                   # 환경 변수

```

## API 엔드포인트

| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | `/` | 에이전트 상태 확인 |
| GET | `/health` | 헬스 체크 |
| POST | `/workflow` | 워크플로우 실행 |
| GET | `/workflows` | 사용 가능한 워크플로우 목록 |

## 보안 고려사항

- 허브와의 통신은 HTTPS와 API 키로 보호됨
- 에이전트는 허브의 IP 주소를 검증함 (옵션)
- 민감한 정보는 환경 변수로 관리
- 로그에 비밀번호나 API 키가 노출되지 않도록 주의

## 기여하기

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 라이선스

이 프로젝트는 MIT 라이선스로 배포됩니다.

## 지원

문제가 발생하거나 질문이 있으시면 [Issues](https://github.com/yourusername/crawler-agent/issues)에 등록해주세요.