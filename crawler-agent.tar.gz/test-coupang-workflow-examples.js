const axios = require('axios');

// Test different scenarios for coupang-search workflow
async function testScenarios() {
    const baseUrl = 'http://localhost:3001';
    
    console.log('=== Coupang Search Workflow Test Examples ===\n');
    
    // Test 1: Basic search with limit
    console.log('1. Basic search with limit:');
    try {
        const response = await axios.post(`${baseUrl}/workflow/run`, {
            module: 'coupang-search',
            params: {
                keyword: '노트북',
                limit: 5
            }
        });
        console.log(`   ✓ Success: Found ${response.data.result.count} products`);
        console.log(`   First product: ${response.data.result.products[0].name}`);
    } catch (error) {
        console.log(`   ✗ Error: ${error.response?.data?.error || error.message}`);
    }
    
    // Test 2: Search without limit (will get more results)
    console.log('\n2. Search without limit:');
    try {
        const response = await axios.post(`${baseUrl}/workflow/run`, {
            module: 'coupang-search',
            params: {
                keyword: '아이폰'
            }
        });
        console.log(`   ✓ Success: Found ${response.data.result.count} products`);
        console.log(`   Total pages crawled: ${response.data.result.totalPages || 1}`);
    } catch (error) {
        console.log(`   ✗ Error: ${error.response?.data?.error || error.message}`);
    }
    
    // Test 3: Search with no results
    console.log('\n3. Search with no results:');
    try {
        const response = await axios.post(`${baseUrl}/workflow/run`, {
            module: 'coupang-search',
            params: {
                keyword: 'xyzabc123impossible'
            }
        });
        if (response.data.result.noResults) {
            console.log(`   ✓ Correctly handled: ${response.data.result.message}`);
        } else {
            console.log(`   ? Unexpected: Found ${response.data.result.count} products`);
        }
    } catch (error) {
        console.log(`   ✗ Error: ${error.response?.data?.error || error.message}`);
    }
    
    // Test 4: Missing required parameter
    console.log('\n4. Missing required parameter:');
    try {
        const response = await axios.post(`${baseUrl}/workflow/run`, {
            module: 'coupang-search',
            params: {
                limit: 10
                // keyword is missing
            }
        });
        console.log(`   ? Unexpected success`);
    } catch (error) {
        console.log(`   ✓ Expected error: ${error.response?.data?.error || error.message}`);
    }
    
    // Test 5: Using alternative endpoint
    console.log('\n5. Using alternative endpoint /api/workflow/:name:');
    try {
        const response = await axios.post(`${baseUrl}/api/workflow/coupang-search`, {
            params: {
                keyword: '맥북',
                limit: 3
            }
        });
        console.log(`   ✓ Success: Found ${response.data.result.count} products`);
    } catch (error) {
        console.log(`   ✗ Error: ${error.response?.data?.error || error.message}`);
    }
    
    console.log('\n=== Test completed ===');
}

// Run tests
testScenarios().catch(console.error);