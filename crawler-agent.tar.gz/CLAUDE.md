# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Status

This is a distributed web crawler agent that communicates with an external hub server.

## Development Setup

1. **Install Dependencies**:
   ```bash
   cd agent && npm install
   # Or use the install script
   ./scripts/install.sh
   ```

2. **Configure Environment**:
   ```bash
   cp .env.example .env
   # Edit .env with hub URL and API key
   ```

3. **Run Agent**:
   ```bash
   npm start  # Single agent on port 3001
   # Or use management script
   ./scripts/manage.sh
   ```

## Architecture Overview

### Agent (Default Port 3001)
- Playwright-based Chrome browser automation
- Runs Chrome in non-headless mode
- Stores user data in `data/users/user_${port}` directory
- Automatic registration with hub
- Heartbeat every 10 seconds
- Reports status to Hub (ready, navigating, completed, error)

### Hub Connection
- Hub URL: Configured in .env (e.g., https://mkt.techb.kr:8443)
- Authentication: X-API-Key header with secret from .env
- Automatic re-registration on 404 errors
- HTTPS with self-signed certificate support

### Communication Flow
1. Agent starts and registers with hub
2. Agent sends heartbeat every 10 seconds
3. Hub sends workflow requests to agent
4. Agent executes workflow using Playwright
5. Agent returns results to hub

## Project Structure

```
agent/
├── src/
│   ├── index.js         # Main agent server
│   └── workflows/       # Workflow modules
├── scripts/             # Management scripts
├── config/              # Configuration files
├── logs/                # Log files
└── data/                # User data and storage
```

## Key Files

- `src/index.js`: Main agent server with Playwright integration
- `src/workflows/`: Workflow modules for different crawling tasks
- `scripts/manage.sh`: Unified management tool for agents
- `config/default.json`: Default configuration values
- `.env`: Environment-specific configuration

## Common Development Tasks

### Adding New Workflows
Create new module in `src/workflows/` directory.

### Running Multiple Agents
```bash
# Start agents on ports 3001-3004
./scripts/manage.sh
# Select option 3 (Start multiple agents)
```

### Monitoring Logs
```bash
tail -f logs/agent.log
# Or use manage.sh option 6
```

### Systemd Service (Linux)
```bash
sudo ./scripts/systemd-setup.sh install-multi
sudo systemctl start crawler-agent@3001
```