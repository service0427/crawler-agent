#!/bin/bash

echo "=== Coupang Search Workflow Test with Monitoring ==="
echo ""
echo "Starting log monitor in background..."

# Start tailing the log in background
tail -f logs/agent1.log | grep -E "(coupang-search|Workflow execution)" &
TAIL_PID=$!

echo "Monitor PID: $TAIL_PID"
echo ""
echo "Executing workflow request..."
echo ""

# Execute the workflow
curl -X POST http://localhost:3001/workflow/run \
  -H "Content-Type: application/json" \
  -d '{
    "module": "coupang-search",
    "params": {
      "keyword": "노트북",
      "limit": 10
    }
  }' 2>/dev/null | jq '.'

echo ""
echo "Workflow completed. Press Ctrl+C to stop monitoring."
echo ""

# Keep the script running
wait $TAIL_PID